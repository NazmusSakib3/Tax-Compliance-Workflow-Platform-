# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: smoke.spec.ts >> Tax Compliance smoke flow >> login through UI and complete generated task via API
- Location: tests/smoke.spec.ts:6:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText(/task occurrences/i)
Expected: visible
Error: strict mode violation: getByText(/task occurrences/i) resolved to 4 elements:
    1) <span class="nav-label" _ngcontent-ng-c1802991606="">Task Occurrences</span> aka getByRole('link', { name: '☑ Task Occurrences Work' })
    2) <h2 class="section-title" _ngcontent-ng-c1094030362="">Task Occurrences</h2> aka getByRole('heading', { name: 'Task Occurrences' })
    3) <label class="sr-only" _ngcontent-ng-c1094030362="" for="task-occurrences-search">Search task occurrences...</label> aka getByText('Search task occurrences...')
    4) <caption class="sr-only" _ngcontent-ng-c1094030362="">Task occurrences</caption> aka getByText('Task occurrences', { exact: true })

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText(/task occurrences/i)

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - generic [ref=e5]:
      - generic [ref=e6]: TC
      - generic [ref=e7]:
        - paragraph [ref=e8]: Tax Compliance
        - paragraph [ref=e9]: Workflow Platform
    - navigation [ref=e10]:
      - link "◫ Dashboard See overdue, due soon, and in-progress work at a glance." [ref=e11] [cursor=pointer]:
        - /url: /dashboard
        - generic [ref=e12]: ◫
        - generic [ref=e13]:
          - generic [ref=e14]: Dashboard
          - generic [ref=e15]: See overdue, due soon, and in-progress work at a glance.
      - link "◎ Organizations Manage the top-level companies in the platform." [ref=e16] [cursor=pointer]:
        - /url: /organizations
        - generic [ref=e17]: ◎
        - generic [ref=e18]:
          - generic [ref=e19]: Organizations
          - generic [ref=e20]: Manage the top-level companies in the platform.
      - link "▣ Legal Entities Track registered entities under each organization." [ref=e21] [cursor=pointer]:
        - /url: /legal-entities
        - generic [ref=e22]: ▣
        - generic [ref=e23]:
          - generic [ref=e24]: Legal Entities
          - generic [ref=e25]: Track registered entities under each organization.
      - link "◉ Jurisdictions Maintain the countries, regions, and filing authorities you report to." [ref=e26] [cursor=pointer]:
        - /url: /jurisdictions
        - generic [ref=e27]: ◉
        - generic [ref=e28]:
          - generic [ref=e29]: Jurisdictions
          - generic [ref=e30]: Maintain the countries, regions, and filing authorities you report to.
      - link "▤ Templates Store reusable filing templates and reminder settings." [ref=e31] [cursor=pointer]:
        - /url: /compliance-templates
        - generic [ref=e32]: ▤
        - generic [ref=e33]:
          - generic [ref=e34]: Templates
          - generic [ref=e35]: Store reusable filing templates and reminder settings.
      - link "⟳ Task Rules Define how recurring compliance work should be generated." [ref=e36] [cursor=pointer]:
        - /url: /task-rules
        - generic [ref=e37]: ⟳
        - generic [ref=e38]:
          - generic [ref=e39]: Task Rules
          - generic [ref=e40]: Define how recurring compliance work should be generated.
      - link "☑ Task Occurrences Work through generated tasks, assignment, comments, and documents." [ref=e41] [cursor=pointer]:
        - /url: /task-occurrences
        - generic [ref=e42]: ☑
        - generic [ref=e43]:
          - generic [ref=e44]: Task Occurrences
          - generic [ref=e45]: Work through generated tasks, assignment, comments, and documents.
      - link "≡ Audit Log Review tracked changes for accountability and audits." [ref=e46] [cursor=pointer]:
        - /url: /audit-log
        - generic [ref=e47]: ≡
        - generic [ref=e48]:
          - generic [ref=e49]: Audit Log
          - generic [ref=e50]: Review tracked changes for accountability and audits.
      - link "◈ Users Invite users and assign platform roles." [ref=e51] [cursor=pointer]:
        - /url: /users
        - generic [ref=e52]: ◈
        - generic [ref=e53]:
          - generic [ref=e54]: Users
          - generic [ref=e55]: Invite users and assign platform roles.
      - link "⛨ Account Security Manage your multi-factor authentication settings." [ref=e56] [cursor=pointer]:
        - /url: /account/security
        - generic [ref=e57]: ⛨
        - generic [ref=e58]:
          - generic [ref=e59]: Account Security
          - generic [ref=e60]: Manage your multi-factor authentication settings.
    - paragraph [ref=e61]: Platform admins can scope the workspace to one organization or browse all tenants.
  - generic [ref=e62]:
    - banner [ref=e63]:
      - generic [ref=e65]:
        - paragraph [ref=e66]: Tax Compliance Workflow Platform
        - paragraph [ref=e67]:
          - text: Welcome back,
          - strong [ref=e68]: Platform Administrator
      - generic [ref=e69]:
        - combobox [ref=e71]:
          - option "All organizations" [selected]
          - option "Demo Org 1782651867345"
          - option "Platform Organization"
          - option "Playwright Org 1782651868544"
        - generic "Platform Administrator" [ref=e72]: PA
        - button "Light mode" [ref=e73] [cursor=pointer]:
          - generic [ref=e75]: Light mode
        - button "Sign out" [ref=e76] [cursor=pointer]
    - main [ref=e77]:
      - generic [ref=e79]:
        - generic [ref=e81]:
          - paragraph [ref=e82]: Generated work
          - heading "Task Occurrences" [level=2] [ref=e83]
          - paragraph [ref=e84]: Generated compliance work items with status, due dates, and assignment.
        - generic [ref=e85]:
          - generic [ref=e86]: Search task occurrences...
          - searchbox "Search task occurrences..." [ref=e87]
          - generic [ref=e88]: Filter by status
          - combobox "Filter by status" [ref=e89]:
            - option "All statuses" [selected]
            - option "Draft"
            - option "Pending"
            - option "In Progress"
            - option "Completed"
            - option "Overdue"
            - option "Cancelled"
          - button "Search" [ref=e90] [cursor=pointer]
        - table "Task occurrences" [ref=e92]:
          - caption [ref=e93]: Task occurrences
          - rowgroup [ref=e94]:
            - row "Rule Entity Jurisdiction Due Date Status Assigned To Details" [ref=e95]:
              - columnheader "Rule" [ref=e96]
              - columnheader "Entity" [ref=e97]
              - columnheader "Jurisdiction" [ref=e98]
              - columnheader "Due Date" [ref=e99]
              - columnheader "Status" [ref=e100]
              - columnheader "Assigned To" [ref=e101]
              - columnheader "Details" [ref=e102]:
                - generic [ref=e103]: Details
          - rowgroup [ref=e104]:
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Jul 15, 2026 Pending Unassigned Open details" [ref=e105]:
              - cell "Monthly VAT Filing" [ref=e106]
              - cell "Acme Holdings LLC" [ref=e107]
              - cell "United States - New York" [ref=e108]
              - cell "Jul 15, 2026" [ref=e109]:
                - generic [ref=e110]: Jul 15, 2026
              - cell "Pending" [ref=e111]:
                - generic [ref=e112]: Pending
              - cell "Unassigned" [ref=e113]
              - cell "Open details" [ref=e114]:
                - link "Open details" [ref=e115] [cursor=pointer]:
                  - /url: /task-occurrences/5c78718f-e96a-4f23-bef3-c4fbf1e6a0b9
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Jul 20, 2026 Completed Unassigned Open details" [ref=e116]:
              - cell "Playwright Monthly Rule" [ref=e117]
              - cell "Playwright Legal Entity" [ref=e118]
              - cell "Playwright Jurisdiction" [ref=e119]
              - cell "Jul 20, 2026" [ref=e120]:
                - generic [ref=e121]: Jul 20, 2026
              - cell "Completed" [ref=e122]:
                - generic [ref=e123]: Completed
              - cell "Unassigned" [ref=e124]
              - cell "Open details" [ref=e125]:
                - link "Open details" [ref=e126] [cursor=pointer]:
                  - /url: /task-occurrences/15baef2a-138e-481c-bbea-2d27fae32b3d
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Aug 15, 2026 Pending Unassigned Open details" [ref=e127]:
              - cell "Monthly VAT Filing" [ref=e128]
              - cell "Acme Holdings LLC" [ref=e129]
              - cell "United States - New York" [ref=e130]
              - cell "Aug 15, 2026" [ref=e131]:
                - generic [ref=e132]: Aug 15, 2026
              - cell "Pending" [ref=e133]:
                - generic [ref=e134]: Pending
              - cell "Unassigned" [ref=e135]
              - cell "Open details" [ref=e136]:
                - link "Open details" [ref=e137] [cursor=pointer]:
                  - /url: /task-occurrences/de285f42-b26c-426b-966f-0841460d0147
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Aug 20, 2026 Pending Unassigned Open details" [ref=e138]:
              - cell "Playwright Monthly Rule" [ref=e139]
              - cell "Playwright Legal Entity" [ref=e140]
              - cell "Playwright Jurisdiction" [ref=e141]
              - cell "Aug 20, 2026" [ref=e142]:
                - generic [ref=e143]: Aug 20, 2026
              - cell "Pending" [ref=e144]:
                - generic [ref=e145]: Pending
              - cell "Unassigned" [ref=e146]
              - cell "Open details" [ref=e147]:
                - link "Open details" [ref=e148] [cursor=pointer]:
                  - /url: /task-occurrences/26e17200-db0f-436e-bcf0-9254d9a88ec1
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Sep 15, 2026 Pending Unassigned Open details" [ref=e149]:
              - cell "Monthly VAT Filing" [ref=e150]
              - cell "Acme Holdings LLC" [ref=e151]
              - cell "United States - New York" [ref=e152]
              - cell "Sep 15, 2026" [ref=e153]:
                - generic [ref=e154]: Sep 15, 2026
              - cell "Pending" [ref=e155]:
                - generic [ref=e156]: Pending
              - cell "Unassigned" [ref=e157]
              - cell "Open details" [ref=e158]:
                - link "Open details" [ref=e159] [cursor=pointer]:
                  - /url: /task-occurrences/92b7cff2-7076-4a99-8b56-6cb046bc1d70
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Sep 20, 2026 Pending Unassigned Open details" [ref=e160]:
              - cell "Playwright Monthly Rule" [ref=e161]
              - cell "Playwright Legal Entity" [ref=e162]
              - cell "Playwright Jurisdiction" [ref=e163]
              - cell "Sep 20, 2026" [ref=e164]:
                - generic [ref=e165]: Sep 20, 2026
              - cell "Pending" [ref=e166]:
                - generic [ref=e167]: Pending
              - cell "Unassigned" [ref=e168]
              - cell "Open details" [ref=e169]:
                - link "Open details" [ref=e170] [cursor=pointer]:
                  - /url: /task-occurrences/ecff656e-c3a8-479d-a317-6f21405d2eeb
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Oct 15, 2026 Pending Unassigned Open details" [ref=e171]:
              - cell "Monthly VAT Filing" [ref=e172]
              - cell "Acme Holdings LLC" [ref=e173]
              - cell "United States - New York" [ref=e174]
              - cell "Oct 15, 2026" [ref=e175]:
                - generic [ref=e176]: Oct 15, 2026
              - cell "Pending" [ref=e177]:
                - generic [ref=e178]: Pending
              - cell "Unassigned" [ref=e179]
              - cell "Open details" [ref=e180]:
                - link "Open details" [ref=e181] [cursor=pointer]:
                  - /url: /task-occurrences/3834f3f2-aaf9-4636-90c2-fad8838900b8
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Oct 20, 2026 Pending Unassigned Open details" [ref=e182]:
              - cell "Playwright Monthly Rule" [ref=e183]
              - cell "Playwright Legal Entity" [ref=e184]
              - cell "Playwright Jurisdiction" [ref=e185]
              - cell "Oct 20, 2026" [ref=e186]:
                - generic [ref=e187]: Oct 20, 2026
              - cell "Pending" [ref=e188]:
                - generic [ref=e189]: Pending
              - cell "Unassigned" [ref=e190]
              - cell "Open details" [ref=e191]:
                - link "Open details" [ref=e192] [cursor=pointer]:
                  - /url: /task-occurrences/60235470-87b5-4775-bd45-44830a0660ed
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Nov 15, 2026 Pending Unassigned Open details" [ref=e193]:
              - cell "Monthly VAT Filing" [ref=e194]
              - cell "Acme Holdings LLC" [ref=e195]
              - cell "United States - New York" [ref=e196]
              - cell "Nov 15, 2026" [ref=e197]:
                - generic [ref=e198]: Nov 15, 2026
              - cell "Pending" [ref=e199]:
                - generic [ref=e200]: Pending
              - cell "Unassigned" [ref=e201]
              - cell "Open details" [ref=e202]:
                - link "Open details" [ref=e203] [cursor=pointer]:
                  - /url: /task-occurrences/32bfecee-8e6c-4c49-94f4-38f36f138ead
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Nov 20, 2026 Pending Unassigned Open details" [ref=e204]:
              - cell "Playwright Monthly Rule" [ref=e205]
              - cell "Playwright Legal Entity" [ref=e206]
              - cell "Playwright Jurisdiction" [ref=e207]
              - cell "Nov 20, 2026" [ref=e208]:
                - generic [ref=e209]: Nov 20, 2026
              - cell "Pending" [ref=e210]:
                - generic [ref=e211]: Pending
              - cell "Unassigned" [ref=e212]
              - cell "Open details" [ref=e213]:
                - link "Open details" [ref=e214] [cursor=pointer]:
                  - /url: /task-occurrences/00d57fc6-13e8-432d-9efc-f79eb16e5e89
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Dec 15, 2026 Pending Unassigned Open details" [ref=e215]:
              - cell "Monthly VAT Filing" [ref=e216]
              - cell "Acme Holdings LLC" [ref=e217]
              - cell "United States - New York" [ref=e218]
              - cell "Dec 15, 2026" [ref=e219]:
                - generic [ref=e220]: Dec 15, 2026
              - cell "Pending" [ref=e221]:
                - generic [ref=e222]: Pending
              - cell "Unassigned" [ref=e223]
              - cell "Open details" [ref=e224]:
                - link "Open details" [ref=e225] [cursor=pointer]:
                  - /url: /task-occurrences/7888d479-57b1-4704-bc8a-3a6a5168054c
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Dec 20, 2026 Pending Unassigned Open details" [ref=e226]:
              - cell "Playwright Monthly Rule" [ref=e227]
              - cell "Playwright Legal Entity" [ref=e228]
              - cell "Playwright Jurisdiction" [ref=e229]
              - cell "Dec 20, 2026" [ref=e230]:
                - generic [ref=e231]: Dec 20, 2026
              - cell "Pending" [ref=e232]:
                - generic [ref=e233]: Pending
              - cell "Unassigned" [ref=e234]
              - cell "Open details" [ref=e235]:
                - link "Open details" [ref=e236] [cursor=pointer]:
                  - /url: /task-occurrences/a53dc1bf-9ba8-44aa-95e4-37612d30ea65
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Jan 15, 2027 Pending Unassigned Open details" [ref=e237]:
              - cell "Monthly VAT Filing" [ref=e238]
              - cell "Acme Holdings LLC" [ref=e239]
              - cell "United States - New York" [ref=e240]
              - cell "Jan 15, 2027" [ref=e241]:
                - generic [ref=e242]: Jan 15, 2027
              - cell "Pending" [ref=e243]:
                - generic [ref=e244]: Pending
              - cell "Unassigned" [ref=e245]
              - cell "Open details" [ref=e246]:
                - link "Open details" [ref=e247] [cursor=pointer]:
                  - /url: /task-occurrences/1c5116cd-e856-445d-9499-76ebeb44a79b
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Jan 20, 2027 Pending Unassigned Open details" [ref=e248]:
              - cell "Playwright Monthly Rule" [ref=e249]
              - cell "Playwright Legal Entity" [ref=e250]
              - cell "Playwright Jurisdiction" [ref=e251]
              - cell "Jan 20, 2027" [ref=e252]:
                - generic [ref=e253]: Jan 20, 2027
              - cell "Pending" [ref=e254]:
                - generic [ref=e255]: Pending
              - cell "Unassigned" [ref=e256]
              - cell "Open details" [ref=e257]:
                - link "Open details" [ref=e258] [cursor=pointer]:
                  - /url: /task-occurrences/cb66cb19-886b-4d69-a6c3-6ce3c1d80a0c
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Feb 15, 2027 Pending Unassigned Open details" [ref=e259]:
              - cell "Monthly VAT Filing" [ref=e260]
              - cell "Acme Holdings LLC" [ref=e261]
              - cell "United States - New York" [ref=e262]
              - cell "Feb 15, 2027" [ref=e263]:
                - generic [ref=e264]: Feb 15, 2027
              - cell "Pending" [ref=e265]:
                - generic [ref=e266]: Pending
              - cell "Unassigned" [ref=e267]
              - cell "Open details" [ref=e268]:
                - link "Open details" [ref=e269] [cursor=pointer]:
                  - /url: /task-occurrences/29ca0709-c1b6-4161-b199-ed837ac63ada
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Feb 20, 2027 Pending Unassigned Open details" [ref=e270]:
              - cell "Playwright Monthly Rule" [ref=e271]
              - cell "Playwright Legal Entity" [ref=e272]
              - cell "Playwright Jurisdiction" [ref=e273]
              - cell "Feb 20, 2027" [ref=e274]:
                - generic [ref=e275]: Feb 20, 2027
              - cell "Pending" [ref=e276]:
                - generic [ref=e277]: Pending
              - cell "Unassigned" [ref=e278]
              - cell "Open details" [ref=e279]:
                - link "Open details" [ref=e280] [cursor=pointer]:
                  - /url: /task-occurrences/e1e41e0a-89a2-49f7-b536-5d63cd779b6f
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Mar 15, 2027 Pending Unassigned Open details" [ref=e281]:
              - cell "Monthly VAT Filing" [ref=e282]
              - cell "Acme Holdings LLC" [ref=e283]
              - cell "United States - New York" [ref=e284]
              - cell "Mar 15, 2027" [ref=e285]:
                - generic [ref=e286]: Mar 15, 2027
              - cell "Pending" [ref=e287]:
                - generic [ref=e288]: Pending
              - cell "Unassigned" [ref=e289]
              - cell "Open details" [ref=e290]:
                - link "Open details" [ref=e291] [cursor=pointer]:
                  - /url: /task-occurrences/cb442ea3-7fc1-4f67-8724-cb3ad9808864
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Mar 20, 2027 Pending Unassigned Open details" [ref=e292]:
              - cell "Playwright Monthly Rule" [ref=e293]
              - cell "Playwright Legal Entity" [ref=e294]
              - cell "Playwright Jurisdiction" [ref=e295]
              - cell "Mar 20, 2027" [ref=e296]:
                - generic [ref=e297]: Mar 20, 2027
              - cell "Pending" [ref=e298]:
                - generic [ref=e299]: Pending
              - cell "Unassigned" [ref=e300]
              - cell "Open details" [ref=e301]:
                - link "Open details" [ref=e302] [cursor=pointer]:
                  - /url: /task-occurrences/c8770cc9-307d-455e-8b27-0d6b63c80a8c
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Apr 15, 2027 Pending Unassigned Open details" [ref=e303]:
              - cell "Monthly VAT Filing" [ref=e304]
              - cell "Acme Holdings LLC" [ref=e305]
              - cell "United States - New York" [ref=e306]
              - cell "Apr 15, 2027" [ref=e307]:
                - generic [ref=e308]: Apr 15, 2027
              - cell "Pending" [ref=e309]:
                - generic [ref=e310]: Pending
              - cell "Unassigned" [ref=e311]
              - cell "Open details" [ref=e312]:
                - link "Open details" [ref=e313] [cursor=pointer]:
                  - /url: /task-occurrences/53411d55-7a44-46f4-a924-ad01daf82113
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Apr 20, 2027 Pending Unassigned Open details" [ref=e314]:
              - cell "Playwright Monthly Rule" [ref=e315]
              - cell "Playwright Legal Entity" [ref=e316]
              - cell "Playwright Jurisdiction" [ref=e317]
              - cell "Apr 20, 2027" [ref=e318]:
                - generic [ref=e319]: Apr 20, 2027
              - cell "Pending" [ref=e320]:
                - generic [ref=e321]: Pending
              - cell "Unassigned" [ref=e322]
              - cell "Open details" [ref=e323]:
                - link "Open details" [ref=e324] [cursor=pointer]:
                  - /url: /task-occurrences/3c51ada2-a487-49e8-93c0-85c43211f5eb
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York May 15, 2027 Pending Unassigned Open details" [ref=e325]:
              - cell "Monthly VAT Filing" [ref=e326]
              - cell "Acme Holdings LLC" [ref=e327]
              - cell "United States - New York" [ref=e328]
              - cell "May 15, 2027" [ref=e329]:
                - generic [ref=e330]: May 15, 2027
              - cell "Pending" [ref=e331]:
                - generic [ref=e332]: Pending
              - cell "Unassigned" [ref=e333]
              - cell "Open details" [ref=e334]:
                - link "Open details" [ref=e335] [cursor=pointer]:
                  - /url: /task-occurrences/365db771-d703-4a04-a489-de787922478c
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction May 20, 2027 Pending Unassigned Open details" [ref=e336]:
              - cell "Playwright Monthly Rule" [ref=e337]
              - cell "Playwright Legal Entity" [ref=e338]
              - cell "Playwright Jurisdiction" [ref=e339]
              - cell "May 20, 2027" [ref=e340]:
                - generic [ref=e341]: May 20, 2027
              - cell "Pending" [ref=e342]:
                - generic [ref=e343]: Pending
              - cell "Unassigned" [ref=e344]
              - cell "Open details" [ref=e345]:
                - link "Open details" [ref=e346] [cursor=pointer]:
                  - /url: /task-occurrences/dd140f27-3ea1-40c2-b3ae-7b598373beee
            - row "Monthly VAT Filing Acme Holdings LLC United States - New York Jun 15, 2027 Pending Unassigned Open details" [ref=e347]:
              - cell "Monthly VAT Filing" [ref=e348]
              - cell "Acme Holdings LLC" [ref=e349]
              - cell "United States - New York" [ref=e350]
              - cell "Jun 15, 2027" [ref=e351]:
                - generic [ref=e352]: Jun 15, 2027
              - cell "Pending" [ref=e353]:
                - generic [ref=e354]: Pending
              - cell "Unassigned" [ref=e355]
              - cell "Open details" [ref=e356]:
                - link "Open details" [ref=e357] [cursor=pointer]:
                  - /url: /task-occurrences/f6e56509-d198-4bd4-a3c8-24336ef1e118
            - row "Playwright Monthly Rule Playwright Legal Entity Playwright Jurisdiction Jun 20, 2027 Pending Unassigned Open details" [ref=e358]:
              - cell "Playwright Monthly Rule" [ref=e359]
              - cell "Playwright Legal Entity" [ref=e360]
              - cell "Playwright Jurisdiction" [ref=e361]
              - cell "Jun 20, 2027" [ref=e362]:
                - generic [ref=e363]: Jun 20, 2027
              - cell "Pending" [ref=e364]:
                - generic [ref=e365]: Pending
              - cell "Unassigned" [ref=e366]
              - cell "Open details" [ref=e367]:
                - link "Open details" [ref=e368] [cursor=pointer]:
                  - /url: /task-occurrences/d810f665-bb76-4a48-abef-8b3e9a71e5c5
        - navigation "Pagination" [ref=e370]:
          - paragraph [ref=e371]: Showing 1-24 of 24
          - generic [ref=e372]:
            - generic [ref=e373]: Per page
            - combobox "Per page" [ref=e374]:
              - option "10" [selected]
              - option "25"
              - option "50"
              - option "100"
          - generic [ref=e375]:
            - button "Previous" [disabled] [ref=e376]
            - generic [ref=e377]: Page 1 of 1
            - button "Next" [disabled] [ref=e378]
      - generic [ref=e379]:
        - generic [ref=e380]: Tax Compliance Workflow Platform
        - generic [ref=e381]: "2026"
```

# Test source

```ts
  12  | 
  13  |     const loginResponse = await request.post(`${apiBaseUrl}/auth/login`, {
  14  |       data: { email: 'admin@taxplatform.local', password: 'Admin123!' }
  15  |     });
  16  |     expect(loginResponse.ok()).toBeTruthy();
  17  |     const loginPayload = await loginResponse.json();
  18  |     const token = loginPayload.data.accessToken as string;
  19  |     const authHeaders = { Authorization: `Bearer ${token}` };
  20  | 
  21  |     const orgResponse = await request.post(`${apiBaseUrl}/organizations`, {
  22  |       headers: authHeaders,
  23  |       data: {
  24  |         name: `Playwright Org ${Date.now()}`,
  25  |         code: `PW${Date.now().toString().slice(-4)}`,
  26  |         description: 'Playwright smoke org',
  27  |         isActive: true
  28  |       }
  29  |     });
  30  |     expect(orgResponse.ok()).toBeTruthy();
  31  |     const organization = await orgResponse.json();
  32  | 
  33  |     // The seeded admin is a platform admin with no default organization, so
  34  |     // organization-scoped writes require the same X-Organization-Id header the
  35  |     // web app sends after an organization is selected.
  36  |     const orgHeaders = { ...authHeaders, 'X-Organization-Id': organization.id as string };
  37  | 
  38  |     const jurisdictionResponse = await request.post(`${apiBaseUrl}/jurisdictions`, {
  39  |       headers: orgHeaders,
  40  |       data: {
  41  |         name: 'Playwright Jurisdiction',
  42  |         countryCode: 'US',
  43  |         regionCode: 'NY',
  44  |         filingAuthority: 'NY Tax Dept',
  45  |         isActive: true
  46  |       }
  47  |     });
  48  |     expect(jurisdictionResponse.ok()).toBeTruthy();
  49  |     const jurisdiction = await jurisdictionResponse.json();
  50  | 
  51  |     const templateResponse = await request.post(`${apiBaseUrl}/compliance-templates`, {
  52  |       headers: orgHeaders,
  53  |       data: {
  54  |         name: `Playwright Template ${Date.now()}`,
  55  |         filingType: 'VAT',
  56  |         description: 'Playwright template',
  57  |         reminderDaysBeforeDue: 5,
  58  |         isActive: true
  59  |       }
  60  |     });
  61  |     expect(templateResponse.ok()).toBeTruthy();
  62  |     const template = await templateResponse.json();
  63  | 
  64  |     const legalEntityResponse = await request.post(`${apiBaseUrl}/legal-entities`, {
  65  |       headers: orgHeaders,
  66  |       data: {
  67  |         organizationId: organization.id,
  68  |         name: 'Playwright Legal Entity',
  69  |         registrationNumber: `PW-REG-${Date.now()}`,
  70  |         taxIdentifier: `PW-TAX-${Date.now()}`,
  71  |         isActive: true
  72  |       }
  73  |     });
  74  |     expect(legalEntityResponse.ok()).toBeTruthy();
  75  |     const legalEntity = await legalEntityResponse.json();
  76  | 
  77  |     const ruleResponse = await request.post(`${apiBaseUrl}/compliance-task-rules`, {
  78  |       headers: orgHeaders,
  79  |       data: {
  80  |         legalEntityId: legalEntity.id,
  81  |         jurisdictionId: jurisdiction.id,
  82  |         complianceTemplateId: template.id,
  83  |         title: 'Playwright Monthly Rule',
  84  |         description: 'Generated in Playwright smoke test',
  85  |         recurrenceType: 1,
  86  |         dueDayOfMonth: 20,
  87  |         isActive: true
  88  |       }
  89  |     });
  90  |     expect(ruleResponse.ok()).toBeTruthy();
  91  | 
  92  |     const generateResponse = await request.post(`${apiBaseUrl}/compliance-task-occurrences/generate`, {
  93  |       headers: orgHeaders
  94  |     });
  95  |     expect(generateResponse.ok()).toBeTruthy();
  96  | 
  97  |     const occurrencesResponse = await request.get(`${apiBaseUrl}/compliance-task-occurrences?page=1&pageSize=5`, {
  98  |       headers: orgHeaders
  99  |     });
  100 |     expect(occurrencesResponse.ok()).toBeTruthy();
  101 |     const occurrencesPayload = await occurrencesResponse.json();
  102 |     expect(occurrencesPayload.items.length).toBeGreaterThan(0);
  103 | 
  104 |     const occurrenceId = occurrencesPayload.items[0].id;
  105 |     const completeResponse = await request.post(`${apiBaseUrl}/compliance-task-occurrences/${occurrenceId}/status`, {
  106 |       headers: orgHeaders,
  107 |       data: { status: 4 }
  108 |     });
  109 |     expect(completeResponse.ok()).toBeTruthy();
  110 | 
  111 |     await page.goto('/task-occurrences');
> 112 |     await expect(page.getByText(/task occurrences/i)).toBeVisible();
      |                                                       ^ Error: expect(locator).toBeVisible() failed
  113 |   });
  114 | });
  115 | 
```